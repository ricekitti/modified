// Knockback Displace - when hitting a target, snap the rotation sideways for a
// tick so the knockback is pushed in "direction" by "angle" (with jitter),
// optionally hiding the rotation change from the server-side view.
//   +0x78  packet hook: hold while rotation is hidden
//   +0x118 input hook:  cancel the swing input while displacing
//   +0x128 attack hook: start a displacement
//   +0x138 / +0x168     tick bookkeeping, restore rotation
//   0x4ab90             direction: -1 / +1
#include "slinky/engine.h"

typedef float v4f __attribute__((vector_size(16), aligned(16)));
typedef int v4i __attribute__((vector_size(16), aligned(16)));
struct Rot { float yaw, pitch; };
struct AttackHook { char pad0[8]; Ctx *ctx; unsigned char phase; unsigned char handled; };   // +0x10 / +0x11
struct PktHook { char pad0[0x24]; int verdict; };

extern "C" float data_2f5fa0;            // "cooldown"
extern "C" float data_2f5fd8;            // "angle"
extern "C" unsigned char data_2f5ff8;    // "require_no_kb"
extern "C" unsigned char data_2f6018;    // "require_weapon"
extern "C" unsigned char data_2f6038;    // "require_kb_enchant"
extern "C" unsigned char data_2f6058;    // "require_facing_away"
extern "C" unsigned data_2f60b8;         // "direction"
extern "C" unsigned char data_2f60e0;    // "hide_rotation"
extern "C" unsigned char data_2f6100;    // "use_last_strafe"
extern "C" unsigned char data_304af0;    // rotation hidden
extern "C" unsigned char data_304af1;    // displacing this tick
extern "C" unsigned char data_304af2;    // displaced last tick
extern "C" unsigned char data_304af3;    // hit seen this tick
extern "C" unsigned data_304af4;         // ticks since reset
extern "C" unsigned data_304af8;         // ticks since displacement
extern "C" Rot data_304b00;              // rotation before displacement
extern "C" int data_304b08;              // last strafe sign
extern "C" const float rdata_156680;
extern "C" const float rdata_156684;
extern "C" const float rdata_156688;
extern "C" const v4i rdata_156690;       // sign mask
extern "C" const float rdata_1566b4;

FN(void *, java_get_minecraft_5, (void *a, void *x));
FN(int, java_get_moving_object_position_3, (void *a, void *x));
FN(void *, java_get_moving_object_position_2, (void *a, void *x));
FN(void *, java_jni_is_instance_of_entity_other_player_mp, (void *a, void *e));
FN(unsigned char, entity_flags_has, (void *a, void *x, int mode));
FN(unsigned char, pending_action_flag, ());
FN(unsigned char, weapons_part, (void *a, void *b, unsigned *flags));
FN(unsigned char, java_call_entity_is_sprinting, (void *a, void *p));
FN(Rot, get_entity_rotation, (void *a, void *p));
FN(unsigned char, yaw_diff_check, (Ctx *c, Rot r, void *target));
FN(unsigned char, increment_wrap, (int ms));
FN(void, apply_player_rotation, (Ctx *c, unsigned char a, int b, int d, Rot r));
FN(unsigned char, random_chance, (float chance));
FN(void *, rot_make_floats, (float lo, float hi));
FN(float, random_rotation, (void *rng));
FN(void, apply_silent_rotation, (Rot r));
FN(void, set_rotation_active, (void *a, void *p, int x));
FN(float, java_get_entity_living_base_move_strafing, (void *a, void *p));
FN(Rot, get_render_state, ());
FN(Rot, rot_add, (Rot a, Rot b));
FN(Rot, rot_sub, (Rot a, Rot b));
FN(void *, get_net_handler, (void *a, void *x));
FN(void, java_set_minecraft_left_click_counter, (void *a, void *x, int y));
FN(void *, java_get_game_settings_key_bindings_8, (void *a, void *x));
FN(void, java_get_key_binding_press_time_2, (void *a, void *k));
extern "C" int knockback_displace_direction();

extern "C" void knockback_displace_part(PktHook *h) {
    if (__atomic_load_n(&data_304af0, __ATOMIC_SEQ_CST) & 1)
        h->verdict = 1;
}

extern "C" void knockback_displace_part_2(char *h) {
    if (__builtin_expect(data_304af1 != 0, 0))
        goto clear;
    if (__builtin_expect(data_304af2 == 0, 1))
        return;
clear:
    h[9] = 0;
}

extern "C" void knockback_displace_part_3(AttackHook *h) {
    if (data_304af1 == 1) {
        h->handled = 1;
        return;
    }
    if (h->phase != 1)
        return;
    Ctx *c = h->ctx;
    void *t = java_get_minecraft_5(c->a, c->c18);
    if (!t || java_get_moving_object_position_3(c->a, t) != 2)
        return;
    void *ent = java_jni_is_instance_of_entity_other_player_mp(c->a, java_get_moving_object_position_2(c->a, t));
    if (!ent || entity_flags_has(c->a, ent, 7))
        return;
    data_304af3 = 1;
    if (data_304af2 || data_304af4 < 9)
        return;
    if (data_2f5fa0 > (float)data_304af8)
        return;
    if (pending_action_flag())
        return;
    if (data_2f5ff8 == 1 && *((unsigned char *)c->p38 + 0x18))
        return;
    unsigned flags;
    unsigned char weapon = weapons_part(c->a, c->b, &flags);
    if (data_2f6018 == 1 && !weapon)
        return;
    if (!(flags & 2) && (data_2f6038 || !java_call_entity_is_sprinting(c->a, c->b)))
        return;
    Rot r = get_entity_rotation(c->a, c->b);
    data_304b00 = r;
    if (data_2f6058 == 1 && !yaw_diff_check(c, r, ent))
        return;
    int dir = knockback_displace_direction();
    if (!dir || !increment_wrap(200))
        return;
    apply_player_rotation(c, 1, 0, 0, data_304b00);
    data_304af1 = 1;
    unsigned char keep = random_chance(rdata_156680);
    float ang = data_2f5fd8;
    float fdir = (float)dir;
    float jit = rdata_156684;
    ang = (ang - random_rotation(rot_make_floats(0.0f, jit))) * fdir;
    float pitch = random_rotation(rot_make_floats(jit, rdata_156688));
    if (!keep) {
        v4f p = {pitch, 0, 0, 0};
        pitch = ((v4f)((v4i)p ^ rdata_156690))[0];
    }
    apply_silent_rotation(Rot{ang, pitch});
    set_rotation_active(c->a, c->b, 0);
    if (data_2f60e0 == 1)
        __atomic_exchange_n(&data_304af0, (unsigned char)1, __ATOMIC_SEQ_CST);
    h->handled = 1;
    data_304af8 = 0;
}

extern "C" void knockback_displace_part_4(AttackHook *h) {
    if (h->phase == 1 && data_304af4 >= 10 && (data_304af3 & 1))
        data_304af4 = 0;
}

extern "C" void knockback_displace_part_5(Hook *h) {
    data_304af4 += 1;
    data_304af8 += 1;
    data_304af2 = data_304af1;
    data_304af3 = 0;
    Ctx *c = h->ctx;
    if (c->f40 == 1) {
        float s = java_get_entity_living_base_move_strafing(c->a, c->b);
        int sgn = (s > 0.0f) - (0.0f > s);

        if (data_2f6100 != 1 || sgn != 0)
            data_304b08 = sgn;
        if (data_304af1 != 1)
            goto publish;
        if (increment_wrap(200)) {
            Rot now = get_entity_rotation(c->a, c->b);
            Rot d = rot_add(now, get_render_state());
            apply_silent_rotation(rot_sub(data_304b00, d));
            set_rotation_active(c->a, c->b, 0);
            void *obj = get_net_handler(c->a, c->c18);
            java_set_minecraft_left_click_counter(c->a, c->c18, 0);
            java_get_key_binding_press_time_2(c->a, java_get_game_settings_key_bindings_8(c->a, obj));
        }
    }
    data_304af1 = 0;
publish:

    {
        unsigned v = 0;

        if (data_304af2)
            v = *(volatile unsigned *)&data_2f60e0;   // original reads the setting as a dword here
        __atomic_exchange_n(&data_304af0, (unsigned char)v, __ATOMIC_SEQ_CST);
    }
}

FN(void, java_get_key_binding_press_time_2, (void *a, void *k));
extern "C" int knockback_displace_direction() {
    int r;
    switch (data_2f60b8) {
    case 0: r = -1; break;
    case 4: r = -data_304b08; break;
    case 2: r = (random_chance(rdata_1566b4) - 1) | 1; break;
    case 3: r = data_304b08; break;
    case 1: r = 1; break;
    default: __builtin_unreachable();
    }

    return r;
}
