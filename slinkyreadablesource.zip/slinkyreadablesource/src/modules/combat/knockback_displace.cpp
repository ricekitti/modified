// Knockback Displace — Allows dealing knockback at a different angle.
// category: combat   descriptor: 0x2f5d60   settings block: 0x2f5f58
// functions: gui knockback_displace_gui, register knockback_displace_register, status knockback_displace_status
// implementation: src/logic/combat/knockback_displace.cpp
#include "slinky/api.h"

S(1567a7); // "%.0f°"
S(1567e3); // "Main"
S(1567e8); // "Condition"
S(1567f2); // "direction"
S(1567fc); // "use_last_strafe"
S(15680c); // "angle"
S(156812); // "cooldown"
S(15681b); // "hide_rotation"
S(156829); // "require_no_kb"
S(156837); // "require_weapon"
S(156846); // "require_kb_enchant"
S(156859); // "require_facing_away"

D(2f5f70);                       // setting num "cooldown"
D(2f5fa8);                       // setting num "angle"
extern "C" float data_2f5fd8;    // current value of setting "angle" (+0x30)
D(2f5fe0);                       // setting bool "require_no_kb"
D(2f6000);                       // setting bool "require_weapon"
D(2f6020);                       // setting bool "require_kb_enchant"
D(2f6040);                       // setting bool "require_facing_away"
D(2f6088);                       // setting enum "direction"
extern "C" unsigned data_2f60b8; // current value of setting "direction" (+0x30)
D(2f60c8);                       // setting bool "hide_rotation"
D(2f60e8);                       // setting bool "use_last_strafe"

extern "C" void knockback_displace_gui(void *a, void *b) {
    W_label(a, b, rdata_1567e3);
    W_enumw(b, a, data_2f6088);
    switch (data_2f60b8) {
    case 3:
    case 4:
        W_bool(b, a, data_2f60e8);
        break;
    }
    W_slider(b, a, data_2f5f70);
    W_slider(b, a, data_2f5fa8);
    W_bool(b, a, data_2f60c8);
    W_label(a, b, rdata_1567e8);
    W_bool(b, a, data_2f5fe0);
    W_bool(b, a, data_2f6000);
    W_bool(b, a, data_2f6020);
    W_bool(b, a, data_2f6040);
}

extern "C" void knockback_displace_register(void *m) {
    R_enum(m, rdata_1567f2, data_2f6088);
    R_bool(m, rdata_1567fc, data_2f60e8);
    R_num(m, rdata_15680c, data_2f5fa8);
    R_num(m, rdata_156812, data_2f5f70);
    R_bool(m, rdata_15681b, data_2f60c8);
    R_bool(m, rdata_156829, data_2f5fe0);
    R_bool(m, rdata_156837, data_2f6000);
    R_bool(m, rdata_156846, data_2f6020);
    R_bool(m, rdata_156859, data_2f6040);
}

extern "C" void knockback_displace_status(void *self) {
    log_fmt(self, 0x20, rdata_1567a7, (double)data_2f5fd8);

}
